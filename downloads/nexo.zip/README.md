# Nexo

**Current Version: v0.3 beta (2026-08-29)**

Nexo is a set of font families replicating the character glyphs seen in certain public transportation displays.

- **Nexo S** - A 5x8 alphanumeric font. Both uppercase and lowercase is supported. (Native: 8px)
- **Nexo L** - A 8x16 alphanumeric font. Both uppercase and lowercase is supported. (Native: 16px)

## Font Variants
- **Default** - The raw glyph as-is. Good when high readability is required (e.g. Video thumbnail), or when the font is used alongside a pre-existing LED grid, which are then fitted onto the grid.
- **DM (Dot-Matrix)** - Each pixels are divided into individual LED dots (Circular-shaped). Good for detailed replication (e.g. High resolution replication of displays)
- **DM Italic** - A slanted variant of **DM (Dot-Matrix)**, which does not align to the grid. This is used to simulate how the eyes perceives a horizontally-scrolling LED (from Right to Left).

## Character List
```
ABCDEFGHIJKLMNOPQRSTUVWXYZ
abcdefghijklmnopqrstuvwxyz
0123456789,↓↑←→$&%█ 
.:<>-^\[]_`{}|~;=+*!"')(#/?@＿
```

## Changelogs
- **v0.1 beta** - Initial release
- **v0.2 beta** - Fix errors in "Nexo L" characters (-, ^)
- **v0.3 beta** - Fix inaccuracies for single & double quotation mark (", ')

## License
This project is licensed under the OFL 1.1 license.

## Disclaimers
The "Nexo" project is an independent initiative and is not affiliated nor endorsed by any public transport operators and/or companies.
The content is provided "as is" without guarantees of completeness or error-free replication.

The Hong Kong Transport Simulation Studio assumes no responsibility or liability for any direct or indirect consequences/loss/damage arising from the use of this font and/or associated information.

(c) Hong Kong Transport Simulation Studio 2026