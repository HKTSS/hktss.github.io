# Nexo

**Current Version: v0.1 beta (2026-08-11)**

Nexo is a set of font families replicating the character glyphs seen in certain public transportation display.

- **Nexo S** - A 5x8 alphanumeric font. Both uppercase and lowercase is supported. (Native: 8px)
- **Nexo L** - A 8x16 alphanumeric font. Both uppercase and lowercase is supported. (Native: 16px)

## Font Variants
- **Default** - The raw glyph as-is. Good when high legibility is required (e.g. Video thumbnails), or when the font is applied onto a pre-existing LED grid.
- **DM (Dot-Matrix)** - Each pixels are divided into individual LED dots (Circular-shaped). Good for detailed simulation/high-resolution use.
- **DM Italic** - A slanted variant of **DM**, which does not align to the grid. This is used to simulate how the eyes perceives a horizontally-scrolling LED marquee.

## Character List
```
ABCDEFGHIJKLMNOPQRSTUVWXYZ
abcdefghijklmnopqrstuvwxyz
0123456789,↓↑←→$&%█ 
.:<>-^\[]_`{}|~;=+*!"')(#/?@＿
```

Hint: Consider using the character `█` with Nexo L to produce background LED grid.

## License
This project is licensed under the [OFL 1.1 License](https://openfontlicense.org/documents/OFL.txt).

## Disclaimers
The "Nexo" project is an independent initiative and is not affiliated nor endorsed by any public transport operators and/or companies.
The content is provided "as is" without guarantees of completeness or error-free replication.

The Hong Kong Transport Simulation Studio assumes no responsibility or liability for any direct or indirect consequences/loss/damage arising from the use of this font and/or associated information.

(c) Hong Kong Transport Simulation Studio 2026